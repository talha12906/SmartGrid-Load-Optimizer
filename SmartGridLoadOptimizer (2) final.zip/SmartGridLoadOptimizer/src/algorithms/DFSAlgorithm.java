package algorithms;

import graph.Graph;
import model.Edge;

import java.util.HashSet;

public class DFSAlgorithm {

    public static void dfs(
            Graph graph,
            String start,
            HashSet<String> visited) {

        visited.add(start);

        System.out.print(start + " ");

        for (Edge edge :
                graph.getAdjacencyList()
                        .get(start)) {

            String neighbor =
                    edge.getDestination();

            if (!visited.contains(neighbor)) {

                dfs(
                        graph,
                        neighbor,
                        visited);
            }
        }
    }
}