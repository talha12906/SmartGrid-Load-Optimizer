package algorithms;

import graph.Graph;
import model.Edge;

import java.util.*;

public class DijkstraAlgorithm {

    static class Node
            implements Comparable<Node> {

        String station;
        int distance;

        public Node(
                String station,
                int distance) {

            this.station = station;
            this.distance = distance;
        }

        @Override
        public int compareTo(Node other) {

            return this.distance
                    -
                    other.distance;
        }
    }

    public static String shortestPath(
            Graph graph,
            String source,
            String destination) {

        HashMap<String,Integer> distance =
                new HashMap<>();

        HashMap<String,String> previous =
                new HashMap<>();

        PriorityQueue<Node> pq =
                new PriorityQueue<>();

        for(String station :
                graph.getStations().keySet()) {

            distance.put(
                    station,
                    Integer.MAX_VALUE);
        }

        distance.put(source,0);

        pq.add(
                new Node(source,0));

        while(!pq.isEmpty()) {

            Node current =
                    pq.poll();

            for(Edge edge :
                    graph.getAdjacencyList()
                            .get(current.station)) {

                String next =
                        edge.getDestination();

                int newDistance =
                        distance.get(
                                current.station)
                        +
                        edge.getWeight();

                if(newDistance <
                        distance.get(next)) {

                    distance.put(
                            next,
                            newDistance);

                    previous.put(
                            next,
                            current.station);

                    pq.add(
                            new Node(
                                    next,
                                    newDistance));
                }
            }
        }

        ArrayList<String> path =
                new ArrayList<>();

        String current =
                destination;

        while(current != null) {

            path.add(current);

            current =
                    previous.get(current);
        }

        Collections.reverse(path);

        return
                "SHORTEST PATH\n\n"
                +
                "Route : "
                +
                path
                +
                "\nCost : "
                +
                distance.get(destination);
    }
}