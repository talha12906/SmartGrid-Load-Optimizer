package algorithms;

import java.util.HashMap;

public class UnionFind {

    private HashMap<String,String> parent;

    public UnionFind() {

        parent =
                new HashMap<>();
    }

    public void makeSet(String node) {

        parent.put(
                node,
                node);
    }

    public String find(String node) {

        if(parent.get(node)
                .equals(node)) {

            return node;
        }

        return find(
                parent.get(node));
    }

    public void union(
            String a,
            String b) {

        String rootA =
                find(a);

        String rootB =
                find(b);

        if(!rootA.equals(rootB)) {

            parent.put(
                    rootA,
                    rootB);
        }
    }
}