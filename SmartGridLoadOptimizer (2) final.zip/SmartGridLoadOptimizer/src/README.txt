SMART GRID LOAD OPTIMIZER SYSTEM


Project Description:

Smart Grid Load Optimizer is a Java based DSA project
that manages electricity distribution using graph algorithms.


Data Structure Used:

1. Graph
   - Implemented using HashMap
   - Adjacency List Representation


2. ArrayList
   - Stores transmission connections


3. HashMap
   - Stores stations and load data


Algorithms Implemented:

1. Dijkstra Algorithm

Purpose:
Finds shortest power transmission route.

Example:

A -> B -> D

Minimum Cost = 15



2. BFS Fault Detection

Purpose:
Checks available stations after transmission failure.



3. DFS Connectivity

Purpose:
Checks complete network connectivity.



4. Kruskal MST

Purpose:
Creates minimum cost power network.



5. Load Optimization

Purpose:
Detects overloaded power stations.



Project Structure:


src

|
|-- model
|     Station.java
|     Edge.java
|
|-- graph
|     Graph.java
|
|-- algorithms
|     DijkstraAlgorithm.java
|     BFSFaultDetector.java
|     DFSConnectivity.java
|     KruskalMST.java
|     UnionFind.java
|     PowerOptimizer.java
|
|-- data
|     SampleData.java
|     LoadData.java
|
|-- gui
|     SmartGridGUI.java
|
Main.java


How To Run:

Compile:

javac Main.java model/*.java graph/*.java algorithms/*.java data/*.java gui/*.java


Run:

java Main


Developed In:

Java Swing
Data Structures and Algorithms
