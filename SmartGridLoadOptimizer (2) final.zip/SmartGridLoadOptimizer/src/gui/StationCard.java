package gui;


import javax.swing.*;
import java.awt.*;



public class StationCard extends JPanel {



    private String station;

    private int load;





    public StationCard(
            String station,
            int load){


        this.station = station;

        this.load = load;



        setLayout(
        new BorderLayout());



        setBorder(
        BorderFactory.createLineBorder(
        Color.BLACK,
        2));



        JLabel name =
        new JLabel(
        "Station " + station,
        SwingConstants.CENTER);



        name.setFont(
        new Font(
        "Arial",
        Font.BOLD,
        16));



        JLabel value =
        new JLabel(
        load + " MW",
        SwingConstants.CENTER);



        value.setFont(
        new Font(
        "Arial",
        Font.PLAIN,
        18));




        JLabel status;



        if(load > 65){


            status =
            new JLabel(
            "HIGH LOAD",
            SwingConstants.CENTER);


            status.setForeground(
            Color.RED);


        }

        else{


            status =
            new JLabel(
            "NORMAL",
            SwingConstants.CENTER);


            status.setForeground(
            Color.GREEN);


        }





        add(
        name,
        BorderLayout.NORTH);



        add(
        value,
        BorderLayout.CENTER);



        add(
        status,
        BorderLayout.SOUTH);



    }



}