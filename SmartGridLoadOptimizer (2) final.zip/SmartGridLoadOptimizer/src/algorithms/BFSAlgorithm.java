package algorithms;

import graph.Graph;
import model.Edge;

import java.util.*;

public class BFSAlgorithm {

    public static void bfs(Graph graph, String start) {

        HashSet<String> visited = new HashSet<>();

        Queue<String> queue =
                new LinkedList<>();

        visited.add(start);
        queue.add(start);

        System.out.println("\nBFS Traversal:");

        while (!queue.isEmpty()) {

            String current = queue.poll();

            System.out.print(current + " ");

            for (Edge edge :
                    graph.getAdjacencyList()
                            .get(current)) {

                String neighbor =
                        edge.getDestination();

                if (!visited.contains(neighbor)) {

                    visited.add(neighbor);
                    queue.add(neighbor);
                }
            }
        }

        System.out.println();
    }
}