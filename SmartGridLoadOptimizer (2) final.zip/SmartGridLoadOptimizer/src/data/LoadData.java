package data;


import java.util.HashMap;



public class LoadData {


    public static HashMap<String,Integer> createLoadData(){


        HashMap<String,Integer> load =
                new HashMap<>();


        load.put(
                "A",
                80);



        load.put(
                "B",
                60);



        load.put(
                "C",
                50);



        load.put(
                "D",
                70);



        return load;

    }


}
