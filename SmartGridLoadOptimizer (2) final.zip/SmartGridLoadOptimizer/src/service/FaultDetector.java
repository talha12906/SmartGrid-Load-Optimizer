package service;


import graph.Graph;
import model.Edge;


import java.util.*;



public class FaultDetector {



public static void createFault(
        Graph graph,
        String a,
        String b){



for(Edge e :
        graph.getAdjacencyList()
                .get(a)){


if(e.getDestination().equals(b)){


e.setFaulty(true);


}


}



for(Edge e :
        graph.getAdjacencyList()
                .get(b)){


if(e.getDestination().equals(a)){


e.setFaulty(true);


}


}



}







public static String detectAffectedStations(
        Graph graph,
        String start){



String result =
        "FAULT ANALYSIS\n\n";



Queue<String> queue =
        new LinkedList<>();



HashSet<String> visited =
        new HashSet<>();



queue.add(start);


visited.add(start);




while(!queue.isEmpty()){



String current =
        queue.poll();



result +=
        current+" ";




for(Edge e :
        graph.getAdjacencyList()
                .get(current)){



if(!e.isFaulty()){



String next =
        e.getDestination();



if(!visited.contains(next)){



visited.add(next);


queue.add(next);


}


}


}



}



return result;



}




}