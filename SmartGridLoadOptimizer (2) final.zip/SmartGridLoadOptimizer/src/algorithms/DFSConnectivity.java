package algorithms;

import graph.Graph;
import model.Edge;

import java.util.HashSet;

public class DFSConnectivity {


    public static String performDFS(
            Graph graph,
            String start) {


        HashSet<String> visited =
                new HashSet<>();


        StringBuilder result =
                new StringBuilder();


        dfs(
            graph,
            start,
            visited,
            result
        );


        return
                "DFS CONNECTIVITY CHECK\n\n"
                +
                "Traversal Order:\n"
                +
                result;
    }



    private static void dfs(
            Graph graph,
            String current,
            HashSet<String> visited,
            StringBuilder result) {


        visited.add(current);


        result.append(current)
                .append(" ");



        for(Edge edge :
                graph.getAdjacencyList()
                        .get(current)) {


            if(!edge.isFaulty()
                    &&
               !visited.contains(
                       edge.getDestination())) {



                dfs(
                    graph,
                    edge.getDestination(),
                    visited,
                    result
                );
            }
        }

    }

}