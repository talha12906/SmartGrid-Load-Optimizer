package gui;


import javax.swing.*;
import java.awt.*;



public class GridStatusPanel extends JPanel {



    public GridStatusPanel(){


        setLayout(
        new GridLayout(4,1));



        setBorder(
        BorderFactory.createTitledBorder(
        "LIVE GRID STATISTICS"));



        add(
        new JLabel(
        "Total Stations : 4"));



        add(
        new JLabel(
        "Active Transmission Lines : 4"));



        add(
        new JLabel(
        "Total Power Load : 260 MW"));



        add(
        new JLabel(
        "GRID STATUS : STABLE"));

    }



}