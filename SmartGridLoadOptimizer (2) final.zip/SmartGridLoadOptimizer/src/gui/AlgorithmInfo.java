package gui;


import javax.swing.*;
import java.awt.*;



public class AlgorithmInfo extends JPanel {



    public AlgorithmInfo(){



        setLayout(
        new BorderLayout());



        JTextArea info =
        new JTextArea();



        info.setFont(
        new Font(
        "Arial",
        Font.PLAIN,
        14));



        info.setText(

        "SMART GRID AI ENGINE\n\n" +

        "Dijkstra:\n" +
        "Finds cheapest power route.\n\n" +

        "BFS:\n" +
        "Detects affected stations after faults.\n\n" +

        "DFS:\n" +
        "Checks network connectivity.\n\n" +

        "Kruskal:\n" +
        "Creates minimum cost grid.\n\n" +

        "Load Optimizer:\n" +
        "Detects overloaded stations."

        );



        info.setEditable(false);



        add(
        new JScrollPane(info),
        BorderLayout.CENTER);



    }


}