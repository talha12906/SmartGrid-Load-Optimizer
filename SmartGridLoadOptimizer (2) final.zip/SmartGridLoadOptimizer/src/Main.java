import graph.Graph;

import gui.SmartGridGUI;

import data.SampleData;



public class Main {



    public static void main(String[] args) {



        Graph smartGrid =
                SampleData.createGrid();



        new SmartGridGUI(
                smartGrid);

    }


}