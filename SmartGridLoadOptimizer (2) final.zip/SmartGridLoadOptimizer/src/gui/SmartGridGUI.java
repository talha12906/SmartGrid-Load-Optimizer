package gui;


import graph.Graph;
import algorithms.*;
import data.LoadData;


import javax.swing.*;
import java.awt.*;



public class SmartGridGUI extends JFrame {



    Graph graph;

    JTextArea output;



    public SmartGridGUI(Graph graph){


        this.graph = graph;



        setTitle(
        "Smart Grid Control Center");



        setSize(
        1400,
        850);



        setDefaultCloseOperation(
        EXIT_ON_CLOSE);



        setLayout(
        new BorderLayout(10,10));






        // HEADER

        JLabel title =
        new JLabel(
        "⚡ SMART GRID LOAD OPTIMIZER CONTROL CENTER ⚡",
        SwingConstants.CENTER);



        title.setFont(
        new Font(
        "Arial",
        Font.BOLD,
        28));



        add(
        title,
        BorderLayout.NORTH);










        // MAIN DASHBOARD


        JPanel dashboard =
        new JPanel();



        dashboard.setLayout(
        new GridLayout(
        1,
        3,
        10,
        10));








        // STATIONS


        JPanel stations =
        new JPanel(
        new GridLayout(
        4,
        1,
        10,
        10));



        stations.setBorder(
        BorderFactory.createTitledBorder(
        "POWER STATIONS"));



        stations.add(
        new StationCard("A",80));


        stations.add(
        new StationCard("B",60));


        stations.add(
        new StationCard("C",50));


        stations.add(
        new StationCard("D",70));



        dashboard.add(
        stations);









        // GRID


        JPanel grid =
        new JPanel(
        new BorderLayout());



        grid.setBorder(
        BorderFactory.createTitledBorder(
        "LIVE GRID MAP"));



        grid.add(
        new GridPanel(),
        BorderLayout.CENTER);



        dashboard.add(grid);









        // OUTPUT


        output =
        new JTextArea();



        output.setFont(
        new Font(
        "Monospaced",
        Font.PLAIN,
        18));



        output.setText(
        "SYSTEM READY\n\n"
        +
        "Choose an operation below.");



        output.setEditable(false);



        JScrollPane result =
        new JScrollPane(
        output);



        result.setBorder(
        BorderFactory.createTitledBorder(
        "AI ANALYSIS"));



        dashboard.add(result);




        add(
        dashboard,
        BorderLayout.CENTER);









        // BUTTON AREA


        JPanel operations =
        new JPanel();



        operations.setBorder(
        BorderFactory.createTitledBorder(
        "GRID OPERATIONS"));





        JButton path =
        new JButton(
        "Find Optimal Route");



        JButton fault =
        new JButton(
        "Simulate Fault");



        JButton dfs =
        new JButton(
        "Check Connectivity");



        JButton mst =
        new JButton(
        "Optimize Network");



        JButton load =
        new JButton(
        "Balance Load");





        operations.add(path);

        operations.add(fault);

        operations.add(dfs);

        operations.add(mst);

        operations.add(load);






        add(
        operations,
        BorderLayout.SOUTH);









        // EVENTS




        path.addActionListener(e->{


        output.setText(

        DijkstraAlgorithm.shortestPath(
        graph,
        "A",
        "D")

        );


        });







        fault.addActionListener(e->{


        BFSFaultDetector.createFault(
        graph,
        "B",
        "D");



        output.setText(

        "⚠ FAULT SIMULATION\n\n"
        +
        "Line B-D is damaged\n\n"
        +
        BFSFaultDetector.detectFault(
        graph,
        "A")

        );


        });







        dfs.addActionListener(e->{


        output.setText(

        DFSConnectivity.performDFS(
        graph,
        "A")

        );


        });








        mst.addActionListener(e->{


        output.setText(

        KruskalMST.generateMST(
        graph)

        );


        });







        load.addActionListener(e->{


        output.setText(

        PowerOptimizer.optimizeLoad(
        graph,
        LoadData.createLoadData())

        );


        });





        setVisible(true);


    }



}