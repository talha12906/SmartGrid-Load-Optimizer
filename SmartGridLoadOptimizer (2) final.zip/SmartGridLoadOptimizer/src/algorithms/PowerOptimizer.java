package algorithms;


import graph.Graph;
import model.Edge;

import java.util.ArrayList;
import java.util.HashMap;



public class PowerOptimizer {



    public static String optimizeLoad(
            Graph graph,
            HashMap<String,Integer> loadData) {



        StringBuilder result =
                new StringBuilder();



        result.append(
                "SMART LOAD OPTIMIZATION\n\n");



        int totalLoad = 0;



        for(String station :
                loadData.keySet()) {


            totalLoad +=
                    loadData.get(station);

        }



        int average =
                totalLoad /
                loadData.size();



        for(String station :
                loadData.keySet()) {



            int load =
                    loadData.get(station);



            result.append(
                    station)
                    .append(" Load : ")
                    .append(load)
                    .append(" MW");



            if(load > average) {


                result.append(
                        "  -> HIGH LOAD");

            }

            else {


                result.append(
                        "  -> NORMAL");

            }



            result.append("\n");

        }



        result.append(
                "\nAverage Load : "
                +
                average
                +
                " MW");



        return result.toString();

    }


}