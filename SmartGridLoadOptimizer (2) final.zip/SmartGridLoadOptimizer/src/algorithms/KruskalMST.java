package algorithms;


import graph.Graph;
import model.Edge;


import java.util.*;


public class KruskalMST {



    public static String generateMST(
            Graph graph) {



        ArrayList<Edge> edges =
                new ArrayList<>();


        HashSet<String> added =
                new HashSet<>();



        for(ArrayList<Edge> list :
                graph.getAdjacencyList()
                        .values()) {



            for(Edge e : list) {


                String key =
                        e.getSource()
                        +
                        e.getDestination();



                String reverse =
                        e.getDestination()
                        +
                        e.getSource();



                if(!added.contains(key)
                        &&
                   !added.contains(reverse)) {



                    edges.add(e);


                    added.add(key);

                }

            }
        }



        Collections.sort(
                edges,
                Comparator.comparingInt(
                        Edge::getWeight));



        UnionFind uf =
                new UnionFind();



        for(String station :
                graph.getStations()
                        .keySet()) {


            uf.makeSet(station);

        }



        ArrayList<Edge> mst =
                new ArrayList<>();


        int totalCost = 0;



        for(Edge edge : edges) {


            String root1 =
                    uf.find(
                    edge.getSource());



            String root2 =
                    uf.find(
                    edge.getDestination());



            if(!root1.equals(root2)) {



                mst.add(edge);



                totalCost +=
                        edge.getWeight();



                uf.union(
                        edge.getSource(),
                        edge.getDestination());

            }

        }



        StringBuilder result =
                new StringBuilder();



        result.append(
                "MINIMUM COST POWER NETWORK\n\n");



        for(Edge e : mst) {


            result.append(e)
                    .append("\n");

        }



        result.append(
                "\nTotal Cost : "
                +
                totalCost);



        return result.toString();

    }

}