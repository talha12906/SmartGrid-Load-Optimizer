package data;


import graph.Graph;
import model.Station;



public class SampleData {


    public static Graph createGrid() {


        Graph graph =
                new Graph();



        // id , load , capacity

        Station A =
                new Station(
                        "A",
                        80,
                        100);



        Station B =
                new Station(
                        "B",
                        60,
                        100);



        Station C =
                new Station(
                        "C",
                        50,
                        100);



        Station D =
                new Station(
                        "D",
                        70,
                        100);




        graph.addStation(A);

        graph.addStation(B);

        graph.addStation(C);

        graph.addStation(D);




        // Transmission Lines


        graph.addEdge(
                "A",
                "B",
                10);



        graph.addEdge(
                "A",
                "C",
                20);



        graph.addEdge(
                "B",
                "D",
                5);



        graph.addEdge(
                "C",
                "D",
                15);



        return graph;

    }


}