package model;

public class Station {

    private String id;
    private int load;
    private int capacity;

    public Station(String id, int load, int capacity) {
        this.id = id;
        this.load = load;
        this.capacity = capacity;
    }

    public String getId() {
        return id;
    }

    public int getLoad() {
        return load;
    }

    public void setLoad(int load) {
        this.load = load;
    }

    public int getCapacity() {
        return capacity;
    }

    public double getLoadPercentage() {
        return ((double) load / capacity) * 100;
    }

    public boolean isOverloaded() {
        return load >= (capacity * 0.9);
    }

    @Override
    public String toString() {
        return id +
                " | Load: " +
                load +
                " MW | Capacity: " +
                capacity +
                " MW";
    }
}