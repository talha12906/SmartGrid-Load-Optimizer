package graph;

import model.Station;
import model.Edge;

import java.util.ArrayList;
import java.util.HashMap;

public class Graph {

    private HashMap<String, Station> stations;

    private HashMap<String,
            ArrayList<Edge>> adjacencyList;

    public Graph() {

        stations =
                new HashMap<>();

        adjacencyList =
                new HashMap<>();
    }

    public void addStation(Station station) {

        stations.put(
                station.getId(),
                station);

        adjacencyList.putIfAbsent(
                station.getId(),
                new ArrayList<>());
    }

    public void addEdge(
            String source,
            String destination,
            int weight) {

        Edge e1 =
                new Edge(
                        source,
                        destination,
                        weight);

        Edge e2 =
                new Edge(
                        destination,
                        source,
                        weight);

        adjacencyList
                .get(source)
                .add(e1);

        adjacencyList
                .get(destination)
                .add(e2);
    }

    public HashMap<String, Station>
    getStations() {

        return stations;
    }

    public HashMap<String,
            ArrayList<Edge>>
    getAdjacencyList() {

        return adjacencyList;
    }

}