package model;

public class Edge {

    private String source;
    private String destination;
    private int weight;
    private boolean faulty;

    public Edge(String source,
                String destination,
                int weight) {

        this.source = source;
        this.destination = destination;
        this.weight = weight;
        this.faulty = false;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public int getWeight() {
        return weight;
    }

    public boolean isFaulty() {
        return faulty;
    }

    public void setFaulty(boolean faulty) {
        this.faulty = faulty;
    }

    @Override
    public String toString() {

        return source +
                " -> " +
                destination +
                " (Cost: " +
                weight +
                ")";
    }
}