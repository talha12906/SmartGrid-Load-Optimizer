package service;


import graph.Graph;
import model.Station;


import java.util.PriorityQueue;



public class LoadBalancer {



public static String balanceLoad(Graph graph){



PriorityQueue<Station> heap =
        new PriorityQueue<>(
        (a,b)->a.getLoad()-b.getLoad());



Station overloaded = null;



for(Station s :
        graph.getStations().values()){



    heap.add(s);



    double usage =
            (double)s.getLoad()
            /
            s.getCapacity();



    if(usage >=0.90){


        overloaded = s;

    }


}




if(overloaded==null){


return
"No Overloaded Station Found";

}



Station receiver =
        heap.poll();




if(receiver==overloaded){


receiver =
heap.poll();

}




int transfer =20;



overloaded.setLoad(
        overloaded.getLoad()
        -
        transfer);



receiver.setLoad(
        receiver.getLoad()
        +
        transfer);




return

"LOAD BALANCING COMPLETE\n\n"

+
"Transferred "
+
transfer
+
" MW\n"

+
"From : "
+
overloaded.getId()

+

"\nTo : "

+
receiver.getId();



}



}