package gui;


import javax.swing.*;
import java.awt.*;



public class GridPanel extends JPanel {



    public GridPanel(){


        setPreferredSize(
                new Dimension(
                450,
                350));

    }



    protected void paintComponent(
            Graphics g){


        super.paintComponent(g);



        // Title

        g.setFont(
                new Font(
                "Arial",
                Font.BOLD,
                18));


        g.drawString(
                "POWER GRID NETWORK",
                130,
                30);



        g.setFont(
                new Font(
                "Arial",
                Font.PLAIN,
                14));



        // Station positions


        drawStation(
                g,
                "A",
                220,
                80);



        drawStation(
                g,
                "B",
                100,
                180);



        drawStation(
                g,
                "C",
                220,
                260);



        drawStation(
                g,
                "D",
                340,
                180);




        // Connections


        g.drawLine(
                220,
                80,
                100,
                180);



        g.drawLine(
                220,
                80,
                340,
                180);



        g.drawLine(
                100,
                180,
                340,
                180);



        g.drawLine(
                220,
                260,
                340,
                180);




        // Costs


        g.drawString(
                "10",
                150,
                120);



        g.drawString(
                "20",
                290,
                120);



        g.drawString(
                "5",
                220,
                170);



        g.drawString(
                "15",
                280,
                230);



    }




    private void drawStation(
            Graphics g,
            String name,
            int x,
            int y){


        g.fillOval(
                x-25,
                y-25,
                50,
                50);



        g.setColor(
                Color.WHITE);



        g.drawString(
                name,
                x-5,
                y+5);



        g.setColor(
                Color.BLACK);

    }

}