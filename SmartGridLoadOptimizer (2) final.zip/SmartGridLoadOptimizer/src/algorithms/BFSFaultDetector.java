package algorithms;

import graph.Graph;
import model.Edge;

import java.util.*;

public class BFSFaultDetector {

    public static void createFault(
            Graph graph,
            String source,
            String destination) {

        for(Edge edge :
                graph.getAdjacencyList()
                        .get(source)) {

            if(edge.getDestination()
                    .equals(destination)) {

                edge.setFaulty(true);
            }
        }

        for(Edge edge :
                graph.getAdjacencyList()
                        .get(destination)) {

            if(edge.getDestination()
                    .equals(source)) {

                edge.setFaulty(true);
            }
        }
    }

    public static String detectFault(
            Graph graph,
            String start) {

        Queue<String> queue =
                new LinkedList<>();

        HashSet<String> visited =
                new HashSet<>();

        StringBuilder result =
                new StringBuilder();

        queue.add(start);

        visited.add(start);

        while(!queue.isEmpty()) {

            String current =
                    queue.poll();

            result.append(current)
                    .append(" ");

            for(Edge edge :
                    graph.getAdjacencyList()
                            .get(current)) {

                if(!edge.isFaulty()) {

                    String next =
                            edge.getDestination();

                    if(!visited.contains(next)) {

                        visited.add(next);

                        queue.add(next);
                    }
                }
            }
        }

        return
                "FAULT DETECTION\n\n"
                +
                "Reachable Stations:\n"
                +
                result;
    }
}